using System;
using System.Collections;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using TripleASP.SiteAdmin.TableEditorControl;

namespace TripleASP.SiteAdmin.TableEditorControl
{
	/// <summary>
	/// Summary description for ValidateEditItem.
	/// </summary>
	public class DataEntryFormItemTemplate : ITemplate
	{
		private DataTable columninfo;
		private string primarykey;

		public DataEntryFormItemTemplate(DataTable columninfo, string primarykey)
		{
			this.columninfo = columninfo;
			this.primarykey = primarykey;
		}

		public void InstantiateIn(Control container)
		{
			Table t = new Table();
			t.Width = new Unit("100%");
			t.CellPadding = 2;
			t.CellSpacing = 2;
			
			DbTypes dbtypes = new DbTypes();
			foreach(DataRow dr in columninfo.Rows)
			{
				string column = dr["COLUMN_NAME"].ToString();
				string dbtype = dr["TYPE_NAME"].ToString();
				bool allownull = Convert.ToBoolean(dr["NullAble"]);
				int precision = Convert.ToInt32(dr["Precision"]);

				if(column == primarykey)
				{
					if(Regex.IsMatch(dbtype,"identity"))
					{
						t.Rows.Add(PrimaryKeyRow(column));
					}
					else
					{
						t.Rows.Add(StringRow(column, true, precision));
					}
				}
				else
				{
					switch (dbtypes.GetDbType(dbtype))
					{
						case SqlDbType.Int:
							t.Rows.Add(TypedRow(column, allownull, ValidationDataType.Integer, "Not an Int"));
							break;
						case SqlDbType.BigInt:
							t.Rows.Add(RegexRow(column, allownull, RegexValidator.BigInt, "Not a BigInt"));
							break;
						case SqlDbType.Text:
						case SqlDbType.NText:
							t.Rows.Add(AreaRow(column, allownull, 12));
							break;

						case SqlDbType.TinyInt:
							t.Rows.Add(RangeRow(column, allownull, "0", "255", "Not a TinyInt"));
							break;
						case SqlDbType.SmallInt:
							t.Rows.Add(RangeRow(column, allownull, "-32,768", "32,767", "Not a SmallInt"));
							break;
						case SqlDbType.Char:
						case SqlDbType.NChar:
							t.Rows.Add(StringRow(column, allownull,precision));
							break;
						case SqlDbType.NVarChar:
						case SqlDbType.VarChar:
							if(precision < 100)
							{
								t.Rows.Add(StringRow(column, allownull,precision));
							}
							else if(precision < 300)
							{
								t.Rows.Add(AreaRow(column, allownull,3,precision));
							}
							else
							{
								t.Rows.Add(AreaRow(column, allownull,6,precision));
							}									
							break;

						case SqlDbType.DateTime:
						case SqlDbType.SmallDateTime:
						case SqlDbType.Timestamp:
							t.Rows.Add(RegexRow(column, allownull, RegexValidator.DateTime, "Invalid Date/Time"));
							break;
						case SqlDbType.Bit:
							t.Rows.Add(RegexRow(column, allownull, RegexValidator.Bit, "Bool/Bit Value"));
							break;
						case SqlDbType.Money:
							t.Rows.Add(TypedRow(column, allownull, ValidationDataType.Currency, "Not Currency"));
							break;
						case SqlDbType.Image:
						case SqlDbType.Binary:
						case SqlDbType.VarBinary:
							t.Rows.Add(ReadOnlyRow(column));
							break;
						default:
							t.Rows.Add(StringRow(column, allownull));
							break;
					}
				}
			}
			dbtypes.Clear();
			container.Controls.Add(t);
		}

		#region Rows
		private TableRow PrimaryKeyRow(string column)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddPrimaryKeyLiteral(column));
			c.Controls.Add(AddPrimaryKey(column));
			r.Cells.Add(c);
			return r;
		
		}

		private TableRow RangeRow(string column, bool allowNull, string min, string max, string message)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column));
			c.Controls.Add(AddRange(column, min, max,message));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow RegexRow(string column, bool allowNull, string regex, string message)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column));
			c.Controls.Add(AddRegex(column, regex,message));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow ReadOnlyRow(string column)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddReadOnly(column));
			r.Cells.Add(c);
			return r;		
		}

		private TableRow TypedRow(string column, bool allowNull, ValidationDataType vdt, string message)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column));
			c.Controls.Add(AddCV(column, vdt,message));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow StringRow(string column, bool allowNull, int precision)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column));
			c.Controls.Add(AddRegex(column, RegexValidator.StringLength(Convert.ToInt32(allowNull),precision), "Invalid string length (" + precision.ToString() + ")"));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow StringRow(string column, bool allowNull)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column));
			//c.Controls.Add(AddCV(column, ValidationDataType.Integer));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow ColumnOnly(string column)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.ColumnSpan = 2;
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			return r;
		}

		private TableRow AreaRow(string column, bool allowNull, int rows)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column, rows));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		private TableRow AreaRow(string column, bool allowNull, int rows, int precision)
		{
			TableRow r = new TableRow();
			TableCell c = new TableCell();
			c.Controls.Add(new LiteralControl(column));
			r.Cells.Add(c);
			c = new TableCell();
			c.Controls.Add(AddTextBox(column, rows));
			c.Controls.Add(AddRegex(column, RegexValidator.StringLength(Convert.ToInt32(allowNull),precision), "Invalid string length (" + precision.ToString() + ")"));
			if(!allowNull)
			{
				c.Controls.Add(AddRFV(column));
			}
			r.Cells.Add(c);
			return r;		
		}

		#endregion

		#region OtherControls

		private LiteralControl AddPrimaryKeyLiteral(string column)
		{
			LiteralControl lc = new LiteralControl();
			lc.ID = "literal" + column;
			lc.DataBinding += new EventHandler(this.BindPrimaryKeyLiteral);
			return lc;
		}

		private HtmlInputHidden AddPrimaryKey(string column)
		{
			HtmlInputHidden hidden = new HtmlInputHidden();
			hidden.ID = column;
			hidden.DataBinding += new EventHandler(this.BindPrimaryKey);
			return hidden;
		}

		#endregion

		#region TextBoxes
		private TextBox AddTextBox(string column)
		{
			TextBox tb = new TextBox();
			tb.DataBinding += new EventHandler(this.BindData);
			tb.ID = column;
			tb.Columns = 64;
			tb.Enabled = true;
			return tb;
		}

		private TextBox AddTextBox(string column, int rows)
		{
			TextBox tb = AddTextBox(column);
			tb.Columns = 50;
			tb.Rows = rows;
			tb.TextMode = TextBoxMode.MultiLine;
			return tb;
		}

		private TextBox AddReadOnly(string column)
		{
			TextBox tb = AddTextBox(column);
			tb.Enabled = false;
			return tb;
		}

#endregion

		#region Validators
		private RequiredFieldValidator AddRFV(string column)
		{
			RequiredFieldValidator rfv = new RequiredFieldValidator();
			rfv.Text = column + " can not be null";
			rfv.ControlToValidate = column;
			rfv.Display = ValidatorDisplay.Dynamic;
			return rfv;
		}

		private CompareValidator AddCV(string column, ValidationDataType vdt, string message)
		{
			CompareValidator cv = new CompareValidator();
			cv.Text = message;
			cv.ControlToValidate = column;
			cv.Display = ValidatorDisplay.Dynamic;
			cv.Operator = ValidationCompareOperator.DataTypeCheck;
			cv.Type = vdt;
			return cv;
		}

		private RegularExpressionValidator AddRegex(string column, string regex, string message)
		{
			RegularExpressionValidator rev = new RegularExpressionValidator();
			rev.Text = message;
			rev.ValidationExpression = regex;
			rev.Display = ValidatorDisplay.Dynamic;
			rev.ControlToValidate = column;
			return rev;
		}
		 

		private RangeValidator AddRange(string column, string min, string max, string message)
		{
			RangeValidator range = new RangeValidator();
			range.Text = message;
			range.MinimumValue = min;
			range.MaximumValue = max;
			range.Display = ValidatorDisplay.Dynamic;
			range.ControlToValidate = column;
			return range;
		}
		#endregion

		#region Binders
		public void BindPrimaryKey(object sender, EventArgs e)
		{
			HtmlInputHidden  hidden = (HtmlInputHidden ) sender;
			DataGridItem container = (DataGridItem) hidden.NamingContainer;
			hidden.Value = ((DataRowView) container.DataItem)[hidden.ID].ToString();
		}

		public void BindPrimaryKeyLiteral(object sender, EventArgs e)
		{
			LiteralControl lc = (LiteralControl) sender;
			DataGridItem container = (DataGridItem) lc.NamingContainer;
			lc.Text = ((DataRowView) container.DataItem)[lc.ID.Substring(7)].ToString() + " (primarykey)";
		}

		public void BindData(object sender, EventArgs e)
		{
			TextBox tb = (TextBox) sender;
			DataGridItem container = (DataGridItem) tb.NamingContainer;
			tb.Text = ((DataRowView) container.DataItem)[tb.ID].ToString();
		}
		#endregion 
	}
}
